int __stdcall GetAveDeskVersion()
{
	return 12;
}