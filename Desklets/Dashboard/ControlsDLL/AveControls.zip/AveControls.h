#ifndef AVE_CONTROLS_HEADER_GUARD_23939
#define AVE_CONTROLS_HEADER_GUARD_23939

#include <windows.h>

typedef DWORD_PTR* AVEHANDLE;

#pragma pack(push, 1)

struct AVE_VERSION
{
	DWORD major;
	DWORD minor;
	DWORD revision;

	DWORD intendedAveDeskVersion;
};

#pragma pack(pop, 1)

// general functions
BOOL __stdcall AveGetVersion(AVE_VERSION* version);


// resources functions
AVEHANDLE __stdcall AveCreateResources(const CHAR* baseFolder);
BOOL __stdcall AveFreeResources(AVEHANDLE handle);

// control container functions
AVEHANDLE __stdcall AveCreateControlContainer(HWND deskletHwnd, AVEHANDLE resources);
BOOL __stdcall AveFreeControlContainer(AVEHANDLE container);

BOOL __stdcall AveAddControlToContainer(AVEHANDLE containerHandle, AVEHANDLE controlHandle);
BOOL __stdcall AveRemoveControlFromContainer(AVEHANDLE containerHandle, const CHAR* name);
AVEHANDLE __stdcall AveGetControlFromContainer(AVEHANDLE containerHandle, const CHAR* name);
BOOL __stdcall AveEmptyContainer(AVEHANDLE containerHandle);

INT __stdcall AveLockContainer(AVEHANDLE containerHandle);
INT __stdcall AveUnlockContainer(AVEHANDLE containerHandle);
BOOL __stdcall AveIsContainerLocked(AVEHANDLE containerHandle);

// control functions
AVEHANDLE __stdcall AveCreateControl(AVEHANDLE container, const CHAR* name, const CHAR* type, DWORD flags, DWORD_PTR* reserved);
BOOL __stdcall AveFreeControl(AVEHANDLE control);


INT __stdcall AveLockControl(AVEHANDLE containerHandle);
INT __stdcall AveUnlockControl(AVEHANDLE containerHandle);
BOOL __stdcall AveIsControlLocked(AVEHANDLE containerHandle);

// container event forwarders
BOOL __stdcall AveForwardMessage(AVEHANDLE containerHandle, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL __stdcall AveForwardMouseWheelForward(AVEHANDLE containerHandle, UINT id, const CHAR* layerName, const POINT* pt, const SIZE* s, DWORD keys, int scrolls);
BOOL __stdcall AveForwardMouseWheelBackward(AVEHANDLE containerHandle, UINT id, const CHAR* layerName, const POINT* pt, const SIZE* s, DWORD keys, int scrolls);
BOOL __stdcall AveForwardMouseDown(AVEHANDLE containerHandle, UINT id, const CHAR* layerName, const POINT* pt, const SIZE* s, DWORD keys);
BOOL __stdcall AveForwardMouseUp(AVEHANDLE containerHandle, UINT id, const CHAR* layerName, const POINT* pt, const SIZE* s, DWORD keys);
BOOL __stdcall AveForwardMouseClick(AVEHANDLE containerHandle, UINT id, const CHAR* layerName, const POINT* pt, const SIZE* s, DWORD keys);
BOOL __stdcall AveForwardMouseOut(AVEHANDLE containerHandle, UINT id, const CHAR* layerName);


// control set/get function
DWORD_PTR __stdcall AveSendMessage(AVEHANDLE controlHandle, UINT msg, WPARAM wParam, LPARAM lParam);


#endif//AVE_CONTROLS_HEADER_GUARD_23939