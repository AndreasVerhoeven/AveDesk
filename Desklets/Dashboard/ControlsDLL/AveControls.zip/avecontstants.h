#ifndef AVECONSTANTS_INCLUDE_GUARD_394336467
#define AVECONSTANTS_INCLUDE_GUARD_394336467

#include <windows.h>


const UINT AV_SHOW = 1;		// shows a control
const UINT AV_HIDE = 2;		// hides a control
const UINT AV_ISVISIBLE = 3;// returns TRUE iff a control is visible

// text structures
#pragma push(pack, 1)
struct AVE_FONT
{
	WCHAR faceName[LF_FACESIZE];
	UINT size;
	UINT style;
};
#pragma pop(pack, 1)

typedef BOOL (__stdcall *AveOnScrollbarNotifyCallback)(void* callbackData, CAveTextField* textField, BOOL becomesVisible, DWORD* data);
typedef BOOL (__stdcall *AveOnEnterCallback)(void* callbackData, CAveTextField* textField);

// text messages
const UINT AV_SET_SELRANGE = 4; // wParam = selstart, lParam = selend
const UINT AV_GET_SETRANGE = 5; // wlParam = pointer to selstart, lParam = pointer to selend
const UINT AV_HAS_SELECTION= 6; // returns TRUE iff the text controls has a selection
const UINT AV_NO_SELECTION = 7; // makes sure the textfield has no selection
const UINT AV_SET_TEXTCOLOR= 8; // sets the text color, lParam = ARGB value with the color
const UINT AV_GET_TEXTCOLOR= 9; // returns the text color as ARGB
const UINT AV_SET_SELBGCOLOR=10; // sets the selection background color, lParam = ARGB value with the color
const UINT AV_GET_SELBGCOLOR=11; // returns the selection background color as ARGB
const UINT AV_SET_FONT      =12; // sets the font. lParam = pointer to AVE_FONT struct
const UINT AV_GET_FONT      =13; // gets the font. lParam = pointer to receiving AVE_FONT struct
const UINT AV_SET_TEXT      =14; // sets the text.lParam = WCHAR* string to set.
const UINT AV_GET_TEXT      =15; // gets the text. wParam = maximum buffer length (including zero-terminator). lParam = receiving WCHAR* buffer.
const UINT AV_GET_TEXT_LEN  = 16; // returns the text length (including zero terminator).
const UINT AV_DELETE_SELECTION=17; // deletes the current selection
const UINT AV_SET_SCROLLBAR  = 18; // sets a scrollbar. lParam = AVEHANDLE to a scrollbar control.
const UINT AV_SET_SCROLLBARCALLBACK=19; // sets a scrollbar notify callback. wParam = callbackData, lParam = AveOnScrollbarNotifyCallback function pointer. 
const UINT AV_SET_ONENTERCALLBACK=20; // sets an on enter callback notify. wParam = callbackData, lParam = AveOnEnterCallback function pointer.
const UINT AV_SET_SMOOTHSCROLLING=21; // sets smoothscrolling. if wParam = TRUE, then it's enabled, otherwise disabled.
const UINT AV_GET_SMOOTHSCROLLING=22;// returns TRUE iff smoothscrolling is enabled

#endif//AVECONSTANTS_INCLUDE_GUARD_394336467