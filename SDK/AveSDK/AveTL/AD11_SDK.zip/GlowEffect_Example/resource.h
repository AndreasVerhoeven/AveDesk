//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_CONFIG                      101
#define IDC_SLIDER1                     1000
#define IDC_FRAMEDURATION               1000
#define IDC_NUMBEROFFRAMES              1001
#define IDC_MAXGLOWLEVEL                1002
#define IDRESET                         1003
#define IDDEFAULT                       1004
#define IDC_PREVIEW                     1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
