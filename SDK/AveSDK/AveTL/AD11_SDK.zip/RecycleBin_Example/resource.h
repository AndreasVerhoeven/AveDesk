//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_CONFIGLABELFORMAT           101
#define IDD_CONFIGIMAGES                102
#define IDD_CONFIGOTHER                 103
#define IDC_FORMAT                      1002
#define IDC_LABEL                       1002
#define IDSETEMPTY                      1003
#define IDC_EMPTYIMG                    1004
#define IDC_ASK                         1005
#define IDC_FULLIMG                     1005
#define IDSETFULL                       1006
#define IDC_NORECYCLE                   1006
#define IDC_EJECTIMG                    1009
#define IDSETEJECT                      1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
